This thesis collects the work realized at Comnet deparment around WebRTC technology. 
Some packages contain extra libraries for the composition of this thesis.
